alert('Promo Spesial Hari Ini Dapatkan Potongan Harga Untuk Barang Yang Anda Inginkan, Silahkan Masukan Kategori Yang Anda Inginkan.');
let item = prompt('Masukan Nama : \n cth: Laptop, Handphone, Mouse, Keyboard, Vga, Motherboad');
switch (item) {
    case 'Laptop':
        alert('Kode Promo Untuk Laptop Adalah : Laptop007');
        break;
    case 'Handphone':
        alert('Kode Promo Untuk Handphone  Adalah : Handphone007');
        break;
    case 'Mouse':
        alert('Kode Promo Untuk Mouse Adalah : Mouse007');
        break;
    case 'Keyboard':
        alert('Kode Promo Untuk Keyboard Adalah : Keyboard007');
        break;
    case 'Vga':
        alert('Kode Promo Untuk 007 Adalah : Vga007');
        break;
    case 'Motherboard':
        alert('Kode Promo Untuk Motherboard Adalah : Motherboard007');
        break;
    default:
        alert('Nama Yang Anda Masukan Salah!!, Silakan Coba lagi...')
}




let laptop = document.querySelector(".laptop");
laptop.setAttribute("src", "laptop 1.jpg")

let caption = document.querySelector(".headerText");
caption.innerHTML = '<strong>Enjoy Being A Pro</strong>'